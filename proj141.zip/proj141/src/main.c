//Alvan and Freeman - Group 141 - ECE 198 - Pattern Matcher

#include <stdbool.h> // booleans, i.e. true and false
#include <stdio.h>   // sprintf() function
#include <stdlib.h>  // srand() and random() functions
#include "ece198.h"

bool joystickCheck(int *sequence, int currLvl);
int joystickVal(ADC_HandleTypeDef adcInstance);
void blinkSeq(int *sequence, int currLvl);
void blink(int LEDInput);

int main(void)
{
    HAL_Init();

    __HAL_RCC_GPIOA_CLK_ENABLE(); // enable port A
    __HAL_RCC_GPIOB_CLK_ENABLE(); // enable port B
    __HAL_RCC_GPIOC_CLK_ENABLE(); // enable port C

    // initialize the pins on nucleo

    InitializePin(GPIOA, GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_9 | GPIO_PIN_8 | GPIO_PIN_10, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL, 0); // on-board LED
    InitializePin(GPIOB, GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_10, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL, 0);              // on-board LED
    InitializePin(GPIOC, GPIO_PIN_7, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL, 0);                                                                   // on-board LED

    InitializePin(GPIOA, GPIO_PIN_0 | GPIO_PIN_1, GPIO_MODE_ANALOG, GPIO_NOPULL, 0);

    SerialSetup(9600);

    while (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13))
    {
    }

    srand(HAL_GetTick());
    int sequence[9];
    int currLvl = 1;
    __HAL_RCC_ADC1_CLK_ENABLE();       // enable ADC 1
    ADC_HandleTypeDef adcInstance;     // this variable stores an instance of the ADC
    InitializeADC(&adcInstance, ADC1); // initialize the ADC instance
                                       // Enables the input pins
                                       // (on this board, pin A0 is connected to channel 0 of ADC1, and A1 is connected to channel 1 of ADC1)
    HAL_Delay(1000);
    while (true)
    {
        lvlDisplay(currLvl);

        blinkSeq(sequence, currLvl);
        HAL_Delay(200);
        int joy[currLvl];
        for (int i = 0; i < currLvl; i++)
        {
            int raw0 = ReadADC(&adcInstance, ADC_CHANNEL_0);
            int raw1 = ReadADC(&adcInstance, ADC_CHANNEL_1);

            // char buff[100];
            // sprintf(buff, "Channel0: %hu, Channel1: %hu\r\n", raw0, raw1); // read to the serial monitor (for debug purposes)
            // SerialPuts(buff);
            if (raw0 > 3200)
            {
                joy[i] = 1;
                blink(1);
                // up
            }
            else if (raw1 < 2800)
            {
                joy[i] = 2;

                blink(2);
                // left
            }
            else if (raw0 < 2800)
            {
                joy[i] = 3;

                blink(3);
                // bot
            }
            else if (raw1 > 3200)
            {
                joy[i] = 4;

                blink(4);
                // right
            }
            else
            {
                i--;
            }
        }
        bool winlose = true; // true is win
        for (int i = 0; i < currLvl; i++)
        {
            if (joy[i] != sequence[i])
            {
                winlose = false;
                break;
            }
        }
        if (!winlose)
        {
            //if they lose, display F for FAIL
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, false);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, false);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, false);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, true);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
            break;
        }
        else if (((sequence[8] == 1) || (sequence[8] == 2) || (sequence[8] == 3) || (sequence[8] == 4))&&winlose == true)
        {
            //if they win, display P for PASS
            HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, false);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, false);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, true);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
            break;
        }
        currLvl++;
    }
    return 0;
}

void blinkSeq(int *sequence, int currLvl)
{
    sequence[currLvl - 1] = (rand() % 4) + 1;

    for (int i = 0; i < currLvl; i++)
    {
        blink(sequence[i]);
    }
    HAL_Delay(200 );
}

void blink(int LEDInput)
{
    if (LEDInput == 1)
    {
        HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
        HAL_Delay(250); // 250 milliseconds == 1/4 second
        HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
        HAL_Delay(250); // 250 milliseconds == 1/4 second
    }
    if (LEDInput == 2)
    {
        HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_6);
        HAL_Delay(250); // 250 milliseconds == 1/4 second
        HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_6);
        HAL_Delay(250); // 250 milliseconds == 1/4 second
    }
    if (LEDInput == 3)
    {
        HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_7);
        HAL_Delay(250); // 250 milliseconds == 1/4 second
        HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_7);
        HAL_Delay(250); // 250 milliseconds == 1/4 second
    }
    if (LEDInput == 4)
    {
        HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_6);
        HAL_Delay(250); // 250 milliseconds == 1/4 second
        HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_6);
        HAL_Delay(250); // 250 milliseconds == 1/4 second
    }
}

void lvlDisplay(int lvl)
{
    /*
    a=C7 - HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true)
    b=A9 - HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true)
    c=A8 - HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, true)
    d=B10 - HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true)
    e=B4 - HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, true)
    f=B5 - HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true)
    g=B3 - HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true)
    */
    if (lvl == 0)
    {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, false);
    }
    else if (lvl == 1)
    {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, false);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, false);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, false);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, false);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, false);
    }
    else if (lvl == 2)
    {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, false);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, false);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
    }
    else if (lvl == 3)
    {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, false);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, false);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
    }
    else if (lvl == 4)
    {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, false);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, false);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, false);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
    }
    else if (lvl == 5)
    {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, false);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, false);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
    }
    else if (lvl == 6)
    {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, false);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
    }
    else if (lvl == 7)
    {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, false);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, false);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, false);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, false);
    }
    else if (lvl == 8)
    {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
    }
    else if (lvl == 9)
    {
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, false);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
    }
}
// This function is called by the HAL once every millisecond
void SysTick_Handler(void)
{
    HAL_IncTick(); // tell HAL that a new tick has happened
    // we can do other things in here too if we need to, but be careful
}