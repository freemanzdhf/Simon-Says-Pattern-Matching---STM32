// #include <stdbool.h> // booleans, i.e. true and false
// #include <stdio.h>   // sprintf() function
// #include <stdlib.h>  // srand() and random() functions
// //#include "LiquidCrystal.h"
// #include "ece198.h"
// // bool inputSequence();
// // void lvlDisplay();
// // void addSequence();
// // int joystickLED();
// int main(void)
// {
//     HAL_Init();

//     __HAL_RCC_GPIOA_CLK_ENABLE(); // enable port A (for the on-board LED, for example)
//     __HAL_RCC_GPIOB_CLK_ENABLE(); // enable port B (for the rotary encoder inputs, for example)
//     __HAL_RCC_GPIOC_CLK_ENABLE(); // enable port C (for the on-board blue pushbutton, for example)

//     // initialize the pins to be input, output, alternate function, etc...

//     InitializePin(GPIOA, GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7 | GPIO_PIN_9 | GPIO_PIN_10, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL, 0); // on-board LED
//     InitializePin(GPIOB, GPIO_PIN_3 | GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_10, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL, 0); // on-board LED
//     InitializePin(GPIOC, GPIO_PIN_7, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL, 0);                                                      // on-board LED

//     InitializePin(GPIOA, GPIO_PIN_0 | GPIO_PIN_1, GPIO_MODE_ANALOG, GPIO_NOPULL, 0);

//     SerialSetup(9600);

//     // while (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13))
//     // {
//     // }
//     __HAL_RCC_ADC1_CLK_ENABLE();       // enable ADC 1
//     ADC_HandleTypeDef adcInstance;     // this variable stores an instance of the ADC
//     InitializeADC(&adcInstance, ADC1); // initialize the ADC instance
//                                        // Enables the input pins
//                                        // (on this board, pin A0 is connected to channel 0 of ADC1, and A1 is connected to channel 1 of ADC1)
    
//     int lvl = 9;
//     int size = 0;
//     int *sequence [];
//     sequence = initializeSequence();
//     //don't really know what's going on with this but we could just use 10 element array 
//     lvlDisplay(1);
//     for (int i = 0; i < lvl; ++i){
//         blinkSequence(sequence, size);
//         if (inputSequence(sequence, size, *something here*)){ //what's the third argument?
//             addSequence(sequence, size);
//             if (i < 8){
//                 lvlDisplay(i+2);
//             }
//         }else{
//             gameLoss(); // has to be defined
//             break;
//         }
//         if (i == 8){
//             gameWon();
//         }
//     }
    
// }
// int* initializeSequence(){
//     int *arr{new int[1]{}};
//     return arr;
//     for (int i{0}; i < )
// }
// bool inputSequence(int *sequence[], int *size, ADC_HandleTypeDef adcInstance)
// {

//     int input[*size];
//     for (int i; i < *size; i++)
//     {
//         input[i] == joystickLED(adcInstance); //guessing this is supposed to be =?
//         blink(input[i]);
//         if (input[i] != sequence[i])
//         {
//             return false;
//         }
//     }
//     return true;
// }
// void lvlDisplay(int lvl)
// {
//     /*
//     a=C7 - HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true)
//     b=A9 - HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true)
//     c=A8 - HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, true)
//     d=B10 - HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true)
//     e=B4 - HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, true)
//     f=B5 - HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true)
//     g=B3 - HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true)
//     */
//     if (lvl == 0)
//     {
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
//         HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, false);
//     }
//     else if (lvl == 1)
//     {
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, false);
//         HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, false);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, false);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, false);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, false);
//     }
//     else if (lvl == 2)
//     {
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
//         HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, false);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, false);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
//     }
//     else if (lvl == 3)
//     {
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
//         HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, false);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, false);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
//     }
//     else if (lvl == 4)
//     {
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, false);
//         HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, false);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, false);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
//     }
//     else if (lvl == 5)
//     {
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
//         HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, false);
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, false);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
//     }
//     else if (lvl == 6)
//     {
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
//         HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, false);
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
//     }
//     else if (lvl == 7)
//     {
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
//         HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, false);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, false);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, false);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, false);
//     }
//     else if (lvl == 8)
//     {
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
//         HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
//     }
//     else if (lvl == 9)
//     {
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, true);
//         HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, true);
//         HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, false);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, true);
//         HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, true);
//     }
// }
// void addSequence(int *sequence[], int *size)
// {
//     int randomLED = (rand()%4)+1;
//     int tempSequence[*size+1];
//     for (int i; i<size;i++ ){
//         //shouldn't it be *size?
//         tempSequence[i] = sequence[i];
//     }
//     tempsequence[*size+1] = randomLED;
//     //out of scope? why are you reassigning main sequence
// }
// void blink(int input){
//      if (input == 1)
//         {
//             HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_6);
//             HAL_Delay(500); // 500 milliseconds == 1/4 second
//             HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_6);
//         }
//         if (input == 2)
//         {
//             HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_6);
//             HAL_Delay(500); // 500 milliseconds == 1/4 second
//             HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_6);
//         }
//         if (input == 3)
//         {
//             HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_7);
//             HAL_Delay(500); // 500 milliseconds == 1/4 second
//             HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_7);
//         }
//         if (input == 4)
//         {
//             HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
//             HAL_Delay(500); // 500 milliseconds == 1/4 second
            
//         }
// }
// void blinkSequence(int *sequence, int size){
//     for (int i = 0; i < size; ++i){
//         blink (sequence[i]); 
//     }
// }
// void gameWon(){
        
//     while (1){
//     HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_6);
//     HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_7);
//     HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);    
//     HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_6);
//     HAL_Delay(500);// 500 milliseconds == 1/4 second
//     HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_6);
//     HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_6);
//     HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_7);
//     HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_5);
//     HAL_Delay(500); // 500 milliseconds == 1/4 second
//     }
// }
// void gameLoss(){

// }
// int joystickLED(ADC_HandleTypeDef adcInstance)
// {
//     int raw0 = ReadADC(&adcInstance, ADC_CHANNEL_0);
//     int raw1 = ReadADC(&adcInstance, ADC_CHANNEL_1);

//     if (raw0 < 2800)
//     {
//         return 1;
//     }
//     if (raw0 > 3200)
//     {
//         return 2;
//     }
//     if (raw1 < 2800)
//     {
//         return 3;
//     }
//     if (raw1 > 3200)
//     {
//         return 4;
//     }
// }